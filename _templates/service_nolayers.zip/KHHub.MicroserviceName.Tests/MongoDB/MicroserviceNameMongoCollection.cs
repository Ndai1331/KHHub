﻿using Xunit;

namespace KHHub.MicroserviceName.Tests.MongoDB;

[CollectionDefinition("MicroserviceName collection")]
public class MicroserviceNameMongoCollection: MicroserviceNameMongoDbCollectionFixtureBase
{

}