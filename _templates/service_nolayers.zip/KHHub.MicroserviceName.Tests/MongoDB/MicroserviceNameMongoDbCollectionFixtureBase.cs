﻿using Xunit;

namespace KHHub.MicroserviceName.Tests.MongoDB;

public class MicroserviceNameMongoDbCollectionFixtureBase : ICollectionFixture<MicroserviceNameMongoDbFixture>
{

}