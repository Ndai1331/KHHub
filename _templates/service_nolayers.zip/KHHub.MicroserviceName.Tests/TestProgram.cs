using KHHub.MicroserviceName.Tests;
using Microsoft.AspNetCore.Builder;
using Volo.Abp.AspNetCore.TestBase;

var builder = WebApplication.CreateBuilder();
builder.Environment.ContentRootPath = GetWebProjectContentRootPathHelper.Get("KHHub.MicroserviceName.csproj"); 
await builder.RunAbpModuleAsync<MicroserviceNameTestsModule>(applicationName: "KHHub.MicroserviceName");

public partial class TestProgram
{
}
