﻿using Volo.Abp.Localization;

namespace KHHub.MicroserviceName.Localization;

[LocalizationResourceName("MicroserviceName")]
public class MicroserviceNameResource
{

}
