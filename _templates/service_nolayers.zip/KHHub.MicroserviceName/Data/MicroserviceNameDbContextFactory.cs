﻿{{~
    if config.database_provider != "ef"
    helpers.delete_this_file
    end
~}}
using System.Runtime.CompilerServices;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace KHHub.MicroserviceName.Data;

/* This class is needed for EF Core console commands
 * (like Add-Migration and Update-Database commands)
 * */
public class MicroserviceNameDbContextFactory : IDesignTimeDbContextFactory<MicroserviceNameDbContext>
{
    {{~ if config.database_management_system == "postgresql" ~}}
    [ModuleInitializer]
    public static void Initialize()
    {
        // https://www.npgsql.org/efcore/release-notes/6.0.html#opting-out-of-the-new-timestamp-mapping-logic
        AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);
    }
    {{~ end ~}}
    
    public MicroserviceNameDbContext CreateDbContext(string[] args)
    {
        {{~ if config.database_management_system == "oracle-devart" ~}}
        var builder = (DbContextOptionsBuilder<MicroserviceNameDbContext>)new DbContextOptionsBuilder<MicroserviceNameDbContext>()
        {{~ else ~}}
        var builder = new DbContextOptionsBuilder<MicroserviceNameDbContext>()
        {{~ end ~}}
            .{{ config.database_management_system_builder_extension_method }}(GetConnectionStringFromConfiguration(), b =>
            {
                b.MigrationsHistoryTable("__MicroserviceName_Migrations");
            });

        return new MicroserviceNameDbContext(builder.Options);
    }

    private static string GetConnectionStringFromConfiguration()
    {
        return BuildConfiguration().GetConnectionString(MicroserviceNameDbContext.DatabaseName)
               ?? throw new ApplicationException($"Could not find a connection string named '{MicroserviceNameDbContext.DatabaseName}'.");
    }

    private static IConfigurationRoot BuildConfiguration()
    {
        var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: false)
            .AddEnvironmentVariables();

        return builder.Build();
    }
}
