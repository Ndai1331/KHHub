﻿namespace KHHub.MicroserviceName;

public class ServiceNameWithoutSuffixRemoteServiceConsts
{
    public const string RemoteServiceName = "MicroserviceName";

    public const string ModuleName = "servicenamewithoutsuffix";
}