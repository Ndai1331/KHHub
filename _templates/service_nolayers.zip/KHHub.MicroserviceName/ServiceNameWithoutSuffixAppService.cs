﻿using KHHub.MicroserviceName.Localization;
using Volo.Abp.Application.Services;

namespace KHHub.MicroserviceName;

public abstract class ServiceNameWithoutSuffixAppService : ApplicationService
{
    protected ServiceNameWithoutSuffixAppService()
    {
        LocalizationResource = typeof(MicroserviceNameResource);
        ObjectMapperContext = typeof(KHHubMicroserviceNameModule);
    }
}