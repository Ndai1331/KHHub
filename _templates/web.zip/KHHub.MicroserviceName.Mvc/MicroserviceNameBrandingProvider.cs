﻿using Microsoft.Extensions.Localization;
using KHHub.MicroserviceName.Localization;
using Volo.Abp.DependencyInjection;
using Volo.Abp.Ui.Branding;

namespace KHHub.MicroserviceName;

[Dependency(ReplaceServices = true)]
public class MicroserviceNameBrandingProvider : DefaultBrandingProvider
{
    private IStringLocalizer<MicroserviceNameResource> _localizer;

    public MicroserviceNameBrandingProvider(IStringLocalizer<MicroserviceNameResource> localizer)
    {
        _localizer = localizer;
    }

    public override string AppName => _localizer["MicroserviceName"];
}
