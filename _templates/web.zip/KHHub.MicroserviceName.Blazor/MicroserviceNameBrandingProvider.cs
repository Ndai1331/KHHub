﻿using Volo.Abp.Ui.Branding;

namespace KHHub.MicroserviceName;

public class MicroserviceNameBrandingProvider : DefaultBrandingProvider
{
    public override string AppName => "MicroserviceName";
}
