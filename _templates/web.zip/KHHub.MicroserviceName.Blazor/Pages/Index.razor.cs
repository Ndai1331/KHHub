﻿namespace KHHub.MicroserviceName.Pages;

public partial class Index
{

}
