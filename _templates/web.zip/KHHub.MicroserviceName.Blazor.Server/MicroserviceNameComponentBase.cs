﻿using KHHub.MicroserviceName.Localization;
using Volo.Abp.AspNetCore.Components;

namespace KHHub.MicroserviceName;

public abstract class MicroserviceNameComponentBase : AbpComponentBase
{
    protected MicroserviceNameComponentBase()
    {
        LocalizationResource = typeof(MicroserviceNameResource);
    }
}
